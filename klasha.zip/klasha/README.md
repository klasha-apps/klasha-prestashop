**  **Klasha Prestshop Module**

Prestashop Klasha payment gateway integration. Visit the Klasha Website to know how Klasha works.
Install to receive payments for your goods in naira from any Mastercard, Visa or Verve card in the world.