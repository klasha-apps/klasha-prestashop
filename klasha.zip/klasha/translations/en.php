<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{klasha}prestashop>klasha_c888438d14855d7d96a2724ee9c306bd'] = 'Your settings have been updated.';
$_MODULE['<{klasha}prestashop>klasha_5dd532f0a63d89c5af0243b74732f63c'] = 'Contact details';
$_MODULE['<{klasha}prestashop>klasha_3ec365dd533ddb7ef3d1c111186ce872'] = 'Details';
$_MODULE['<{klasha}prestashop>payment_execution_e2867a925cba382f1436d1834bb52a1c'] = 'The total amount of your order is:';
$_MODULE['<{klasha}prestashop>payment_return_b2f40690858b404ed10e62bdf422c704'] = 'Amount';
